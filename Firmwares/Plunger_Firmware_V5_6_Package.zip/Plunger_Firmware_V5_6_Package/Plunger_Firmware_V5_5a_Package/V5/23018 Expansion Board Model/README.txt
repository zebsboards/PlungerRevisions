

zebsboards PincabController
March 2023 V5R6_Expansion_16bit

Compatibility - All V3 plungers in existence

Changelog:

  Pinball input control software written and developed by Zeb (Steve Ridgley)
                                     http://www.zebsboards.com

  *************************************************************************************************************************************
      Tested on very little with the high possibility that it may work under Visual Pinball, PBFX2, TPA, PinMame and Future Pinball
      Written and developed under the influence; specifically beer.
      Recompling is unnecessary for making it work.. compiles everytime....doesn't mean it works.
  *************************************************************************************************************************************
V5R6_March 2023 Revision

  Plunger Serial Number V5R5104242022HB (as identified in Plunger USB Properties)

  Revisions to software include: 
  
  - Added Gamepad/Keyboard select through Right Flipper/Start Button combination press to V5 Plungers - Does not work with expander boards - use calibration button/switch instead
    


V4Rev5.4_September 2021 Revision

  Plunger Serial Number V4R5109072021HB (as identified in Plunger USB Properties)

  Revisions to software include:

  - Added support for i2c accelerometer, onboard calibration switch (V4R5+ plungers only-coming soon), I/O expansion, future configuration utility software

  - Changed accelerometer reporting to 16bit resolution from 8bit for greater response range

  - Revised Gain Adjustment values and routine for greater range and better reporting

  - Revised auto centering routine to work in conjunction with gain adjustment eliminating any offset at rest

  - Keyboard mode now works in conjunction with Gamepad mode for easier visual confirmation of button presses, Gamepad only mode still available

  - Moved TILT button to Button 17 and linked external input capability for tilt bobs

  - Added support for 2 x I/O i2c expanders (32 button inputs total) - expanders available soon

  - Added TILT Enable/Disable by serial command ('T' - enables/disables based on previous state)

  - Reformatted serial commands to single character ('G' - gamepad, 'K' - keyboard, 'A' - analog mode, 'D' - digital mode, 'T' - Tilt Enable/Disable)

  - Added 2x D-pads to report to allow for native joystick control - requires I/O expansion board

  - Added infrastructure for future external button/key assignment through serial transmission - software based configuration utility

  - Added firmware based detection and selection of existing hardware 

  - Requires Reset batch file (ZBRST.bat) to be run and plunnger to be rebooted!!!!


To Update the firmware:

!!!!! MAKE SURE THAT NO OTHER USB PROGRAMMABLE DEVICES ARE CONNECTED TO THE SYSTEM !!!!!!!!!!!!

- unzip install folder to desktop
- open bootloader finder folder and follow instructions in README
- return to firmware folder and make the changes required in the remarks statements of the RUNME bat file
- save and close the file
- doubleclick on the "RunMe_***" file from within the working folder 
- A command box will open and the file will update itself
- Edit the ZBRST.bat in the Serial folder and enter the correct comport where indicated, save file and run.
- Unplug the usb and reconnect it to reboot the plunger
