

zebsboards PincabController
March 2017 V3 Rev2 A10K 
Changelog

- Fix Serial enabled bug in firmware


To Update the firmware:

- unzip install folder to desktop
- right click on the "RunMe" file and choose edit
- make the changes required in the remarks statements

*NOTE - to find the com port # of the bootloader you need to show non-present devices in Windows using Device Manager:

--     open the device manager and make note of the com port the controller is using
--     edit the comport assignment in the readme for the controller com port (1st entry) and save the file
--     run the RunMe.bat file and let the program error out - this will install the bootloader in your system
--     open a command prompt window
--     change directory to the root directory (cd..[ENTER], repeat until at the C: prompt)
--     change directory into C:Windows\System32
--     type SET DEVMGR_SHOW_NONPRESENT_DEVICES=1 and hit Enter:
--     type DEVMGMT.msc and hit Enter
--     the Device manager screen should now be open, go to the view tab and select SHOW HIDDEN DEVICES from the drop down menu
--     In the Device Manager under (COM & LPT ) Ports you should see the Bootlader COMXX displayed as a non present device make a note of the Com Port 
	(it may help to unplug the plunger from the usb port and reconnect it while displaying the window, the comport that opens and then closes is the bootloader comport).
--     edit the comport assignment in the readme for the bootloader com port (1st entry) and save the file

- save and close the file
- doubleclick on the "RunMe_A10K" file from within the working folder 
- A command box will open and the file will update itself
