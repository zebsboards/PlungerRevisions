

zebsboards PincabController
November 2019 V3R5.1
Changelog

- Repair code for tilt sensitivity
- Add in Serial switching between gamepad and keyboard mode
- Add serial switching between analog and digital launch (zblaunch) / remove physical wiring connection in pinout

To Update the firmware:

!!!!! MAKE SURE THAT NO OTHER USB PROGRAMMABLE DEVICES ARE CONNECTED TO THE SYSTEM !!!!!!!!!!!!

- unzip install folder to desktop
- open bootloader finder folder and follow instructions in README
- return to firmware folder and make the changes required in the remarks statements of the RUNME bat file
- save and close the file
- doubleclick on the "RunMe" file from within the working folder 
- A command box will open and the file will update itself
