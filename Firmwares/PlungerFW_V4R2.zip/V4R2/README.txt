README

This firmware should be compatible with all V3 plungers from V3R2 to current.  

This firmware is likely not compatible with original V3 plungers with the acceleromter daughter board attached to the underside.