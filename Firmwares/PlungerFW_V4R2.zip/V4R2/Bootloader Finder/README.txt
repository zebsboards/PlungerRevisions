Bootloader finder


1.	Open the windows control panel and navigate to Device Manager

2.	Expand Ports (COM & LPT) tree.

3.	Make note of Com port of USB Serial Device.  If more than one exists, Right click and select properties of device, 
        select details tab and Device instance path in the Property selection box and verify VID &PID of product 
        (plunger will display USB\VID_20A0&PID_41B6&MI_00\6&2973B159&0&0000).  Once found close properties and leave device manager open.  

4.	Open the ZBPortFinder.bat file found in this directory in notepad

5.	Change the comport number where indicated to the comport number found in previous step. Save file.

6.	With the device manager screen in view double click on the ZBPortFinder.bat file.
	Watch the USB Serial Device com port listing, after a second or 2 it will disappear and a new port will appear.
	Make note of the com port of the device that appears (device only appears for a brief time before reset is completed and original port reaapears).

7.	The comport number found is the bootloader comport reqired for flashing the firmware in the firmware folder.
