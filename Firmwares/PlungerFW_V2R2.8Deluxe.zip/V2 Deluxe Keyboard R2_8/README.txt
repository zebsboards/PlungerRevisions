

zebsboards PincabController
July 2018 V2 Deluxe R2.8
Changelog

Activated full range scaling in plunger axis (z)



Further revisions to the code will be coming over the next while.


To Update the firmware:

- unzip install folder to desktop
- right click on the "RunMe" file and choose edit
- make the changes required in the remarks statements

*NOTE - to find the com port # of the bootloader you need to show non-present devices in Windows using Device Manager:

--     open the device manager and make note of the com port the pincab controller is using
--     edit the comport assignment in the readme for the pincab controller com port (1st entry) and save the file
--     run the RunMe.bat file and let the program error out - this will install the bootloader in your system
--     open a command prompt window
--     change directory to the root directory (cd..[ENTER], repeat until at the C: prompt)
--     change directory into C:Windows\System32
--     type SET DEVMGR_SHOW_NONPRESENT_DEVICES=1 and hit Enter:
--     type DEVMGMT.msc and hit Enter
--     the Device manager screen should now be open, go to the view tab and select SHOW HIDDEN DEVICES from the drop down menu
--     In the Device Manager under (COM & LPT ) Ports you should see COMXX displayed as a non present device make a note of the Com Port


- save and close the file
- doubleclick on the "RunMe" file from within the working folder (Pincab2016)
- A command box will open and the file will update itself
