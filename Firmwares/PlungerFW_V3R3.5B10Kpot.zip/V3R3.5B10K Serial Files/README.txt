Step 1

	Open Device manager and take note of COM port assigned to controller (eg: COM14)

Step 2:

	Right-click on ZBGP.bat and select EDIT
	Change COM port number in SET PORT=COM4 line to COM number found in previous step
	Save file
	
	Right-click on ZBKB.bat and select EDIT
	Change COM port number in SET PORT=COM4 line to COM number found in previous step
	Save file
	
	Right-click on ZBLA.bat and select EDIT
	Change COM port number in SET PORT=COM4 line to COM number found in previous step
	Save file

	Right-click on ZBLD.bat and select EDIT
	Change COM port number in SET PORT=COM4 line to COM number found in previous step
	Save file

Step 3:

	Copy all four .bat files and .vbs files to VisualPinball\Tables directory

	
Step 4:

	Follow instructions for Serial Control in the Zebsboards Plunger Instruction Manual



