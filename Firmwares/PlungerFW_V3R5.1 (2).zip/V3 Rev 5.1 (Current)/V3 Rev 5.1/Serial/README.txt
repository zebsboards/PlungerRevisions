Step 1

	Open Device manager and take note of COM port assigned to controller (eg: COM14)

Step 2:

	Right-click on ZBStart.bat and select EDIT (select notepad if prompted)
	Change COM port number in SET PORT=COM4 line to COM number found in previous step
	Save file

	Right-click on OFF.bat and select EDIT
	Change COM port number in SET PORT=COM4 line to COM number found in previous step
	Save file
	
	Right-click on ON.bat and select EDIT
	Change COM port number in SET PORT=COM4 line to COM number found in previous step
	Save file

Step 3:

	To use the serial port to control the solenoid power switching the file ZBStart is run once upon startup of the 
	computer to configure the serial port for proper communication and to ensure that the controller starts in the "OFF" state.

	To install Serial control start up file in the Windows Startup folder:

	 - Right Click on Install.bat and select "Run as Administrator"
	 - Click on Allow in the pop up window if it appears
	 - press any key to exit after seeing "1 file(s) copied successfully" message

Step 4:

	Copy ON.bat file and ON.vbs file to PinballX folder and create link to run ON.vbs at table start (run before)

	Copy OFF.bat file and OFF.vbs file to PinballX folder and create link to run OFF.vbs at table exit (run after)



