README

This firmware is to be used with V3 Plungers mounted in teh Newest Housing Only.
Upgrading the firmware without changing to the new housing design will result in a lack of performance.