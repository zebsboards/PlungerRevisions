Extract files and move to root of firmware folder (23017/23018)
edit Runme batch file in folder to match firmware name being flashed
edit batch file to match comports for plunger and bootloader.