

zebsboards PincabController
July 2018 V2 Deluxe R2.8
Changelog

Activated full range scaling in plunger axis (z)



Further revisions to the code will be coming over the next while.


To Update the firmware:

- unzip install folder to desktop
- Open the Bootloader Finder folder and follow instructions in README
- Return to main firmware folder
- right click on the "RunMe" file and choose edit
- make the changes required in the remarks statements
- save and close the file
- doubleclick on the "RunMe" file from within the working folder 
- A command box will open and the file will update itself
